
Code runs as normal:

python Davis_CSCI3202_Assignment8_Part1


--

Emission probabilties are unsorted

Syntax is slightly different for Transition Probabilties

Initial Probabilities should follow original assignment format.